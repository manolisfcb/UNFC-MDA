# Define a function to split x and y into train and test sets
def train_test_split(x, y, test_size=0.2):
    # We need to shuffle the data to avoid any bias in the split
    # Combine the x and y values into tuples (pairs) so they stay together after shuffling
    
    # Shuffle the combined list randomly
    
    # Find the index at which to split the list into training and testing sets
    
    # Create the training set by taking the first part of the shuffled list
    
    # Create the testing set by taking the remaining part of the shuffled list
    
    # Create empty lists to hold separated x and y values for the training set
    # Fill x_train and y_train by looping through each pair in the training set

    # Create empty lists to hold separated x and y values for the testing set
    # Fill x_test and y_test by looping through each pair in the testing set
    
    # Return the four lists: x_train, x_test, y_train, y_test
    pass

def data_summary(values):
    # Do the computations with simple native python computations

    # Return all summary results in a dictionary
    pass