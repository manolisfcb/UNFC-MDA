def fit_regression(x, y):
    # Calculate the number of points (n)
    
    # Calculate the mean of x and y
    
    # Calculate the numerator and denominator for the slope (m)
    
    # Check if the denominator is zero to avoid division by zero
    
    # Calculate the slope (m) and intercept (b)
    
    # Return both slope and intercept
    pass

def predict_regression(x_values, m, b):
    # Create an empty list to store the predicted y-values
    
    # Loop through each x in the list of x_values
    
    # For each x, calculate the predicted y using the formula y = m*x + b
    
    # Add each predicted y-value to the list
    
    # Return the list of all predicted y-values
    pass

def compute_residuals(y_true, y_pred):
    # Create an empty list to store residuals
    
    # Loop through each index in the range of y_true
    
    # For each index, calculate the residual as (actual y - predicted y)
    
    # Add each residual to the list
    
    # Return the list of residuals
    pass
