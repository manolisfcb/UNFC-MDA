def main():
    # Initialize data
    X = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    Y = [3, 6, 9, 12, 15, 18, 21, 24, 27, 55]

    # Print X and Y to check the data


    # Call the fit_regression function
    # and store the returned slope (m) and intercept (b)
    

    # call the predict_regression function
    # and store the returned list of predicted y-values
   

    #Call the compute_residuals function
    #and store the returned list of residuals
    

if __name__ == "__main__":
    main()